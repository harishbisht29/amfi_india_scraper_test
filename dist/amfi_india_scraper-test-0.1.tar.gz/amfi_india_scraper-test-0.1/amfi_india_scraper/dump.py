import requests
import os 
API_url = "https://www.amfiindia.com/modules/LoadModules/navreports"

headers = {
# Accept: text/html, */*; q=0.01
# Accept-Encoding: gzip, deflate, br
# Accept-Language: en-US,en;q=0.9,ru;q=0.8
# Connection: keep-alive
# Cookie: __utmc=57940026; __utmz=57940026.1572682347.1.1.utmcsr=google|utmccn=(organic)|utmcmd=organic|utmctr=(not%20provided); __utma=57940026.1153581557.1572682347.1572710474.1572720470.7; __utmt=1; __utmb=57940026.2.10.1572720470
'X-Requested-With': 'XMLHttpRequest',
'Host': 'www.amfiindia.com',
'Referer': 'https://www.amfiindia.com/net-asset-value'
# Sec-Fetch-Mode: cors
# Sec-Fetch-Site: same-origin
# User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36


}

# response = requests.get(API_url, headers= headers)
# PARAMS = {
    
# }
# print(response.text)

payload = {
'MFName': '2-4',
'OpenScheme':'',
'CloseScheme':'',
'IntervalFund':''
}
r = requests.post(
url='https://www.amfiindia.com/modules/NAVList',
data=payload,
# headers={
# 'X-Requested-With': 'XMLHttpRequest',
# # 'Host': 'www.amfiindia.com',
# # 'Referer': 'https://www.amfiindia.com/net-asset-value',
# # 'Origin': 'https://www.amfiindia.com',
# # 'Sec-Fetch-Mode': 'cors',
# # 'Sec-Fetch-Site': 'same-origin',
# # 'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36',
# # 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
# # 'Accept': '*/*',
# # 'Accept-Encoding': 'gzip, deflate, br',
# # 'Accept-Language': 'en-US,en;q=0.9,ru;q=0.8',
# # 'Content-Length': '49'
# }
)
print("----------------------")
print(r.text)
