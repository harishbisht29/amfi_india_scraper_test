from amfi_india_scraper.Fund import Fund
from amfi_india_scraper.MF_House import MF_House
